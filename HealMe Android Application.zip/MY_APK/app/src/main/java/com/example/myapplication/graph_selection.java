package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

public class graph_selection extends AppCompatActivity {
    private ImageView bg;
    private ImageButton hgr,wgr,cgr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_graph_selection);
        bg=findViewById(R.id.bggraph);
        hgr=findViewById(R.id.hgraph);
        wgr=findViewById(R.id.wgraph);
        cgr=findViewById(R.id.comgraph);



        hgr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(graph_selection.this,heightchart.class);
                startActivity(intent);
                Toast.makeText(graph_selection.this, "HEIGHT V/S TIME", Toast.LENGTH_SHORT).show();
            }
        });

        wgr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(graph_selection.this, "WEIGHT V/S TIME", Toast.LENGTH_SHORT).show();
                Intent intent=new Intent(graph_selection.this,weightchart.class);
                startActivity(intent);
            }
        });

        cgr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(graph_selection.this, "PROGRESS V/S GOAL", Toast.LENGTH_SHORT).show();
                Intent intent=new Intent(graph_selection.this,progress.class);
                startActivity(intent);
            }
        });


    }
}