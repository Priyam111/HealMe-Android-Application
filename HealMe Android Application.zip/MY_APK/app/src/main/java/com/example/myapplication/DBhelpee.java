package com.example.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBhelpee  extends SQLiteOpenHelper {
    public static final String dbname="healme_fin.db";
    public DBhelpee(Context context) {
        super(context, dbname, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase DB) {

        String cr=("create table  alluserdata(weight String,height String,name String,dob String,Thyroid Boolean, Dibatic Boolean, Heart Boolean, Bp INTEGER,Enttime String ,Id INTEGER,Pic BLOB,Sex INTEGER)");
        DB.execSQL(cr);
    }

    @Override
    public void onUpgrade(SQLiteDatabase DB, int i, int i1) {
        DB.execSQL("drop table if exists alluserdata");
        onCreate(DB);
    }

    public Boolean insert(String weight,String height, String name, String dob ,Boolean Thyroid, Boolean Dibatic, Boolean Heart,int Bp,String Enttime,int Id,byte[] Pic,int Sex) {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("weight", weight);
        contentValues.put("height", height);
        contentValues.put("name", name);
        contentValues.put("dob", dob);
        contentValues.put("Thyroid", Thyroid);
        contentValues.put("Dibatic", Dibatic);
        contentValues.put("Heart", Heart);
        contentValues.put("Bp", Bp);
        contentValues.put("Enttime", Enttime);
        contentValues.put("Id", Id);
        contentValues.put("Pic", Pic);
        contentValues.put("Sex", Sex);


        long result = DB.insert("alluserdata", null, contentValues);
        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }

    public Boolean update(String weight,String height, String name, String dob ,Boolean Thyroid, Boolean Dibatic, Boolean Heart,int Bp,String Enttime,int Id,byte[] Pic,int Sex) {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("weight", weight);
        contentValues.put("height", height);
        contentValues.put("name", name);
        contentValues.put("dob", dob);
        contentValues.put("Thyroid", Thyroid);
        contentValues.put("Dibatic", Dibatic);
        contentValues.put("Heart", Heart);
        contentValues.put("Bp", Bp);
        contentValues.put("Id", Id);
        contentValues.put("Pic", Pic);
        contentValues.put("Sex", Sex);
        Cursor cursor = DB.rawQuery("Select * from alluserdata where name=?", new String[]{name});
        if (cursor.getCount() > 0) {
            long result = DB.update("alluserdata", contentValues, "name=?", new String[]{name});
            if (result == -1) {
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }
    }


    public Boolean delete(String name) {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        Cursor cursor = DB.rawQuery("Select * from alluserdata where name=?", new String[]{name});
        if (cursor.getCount() > 0) {
            long result = DB.delete("alluserdata", "name=?", new String[]{name});
            if (result == -1) {
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }
    }

    public Cursor getdata() {
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("Select * from alluserdata", null);
        return cursor;
    }

    public Cursor getsaved() {
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cr_ = DB.rawQuery("Select * from alluserdata where Enttime=MAX", null);
        return cr_;
    }

    public Cursor getprofdata() {
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("Select weight from alluserdata", null);
        return cursor;
    }

}
