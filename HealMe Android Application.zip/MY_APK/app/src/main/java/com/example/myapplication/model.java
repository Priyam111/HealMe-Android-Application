package com.example.myapplication;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class model {
    private int fp;
    private String fn,cd,ci,data;

    model(int fp,String fn,String ci,String cd){
        this.fp=fp;
        this.fn=fn;
        this.cd=cd;
        this.ci=ci;

    }



    public int getFp() {
        return fp;
    }

    public String getCi() {
        return ci;
    }

    public String getFn() {
        return fn;
    }

    public String getCd() {
        return cd;
    }

//    public int getPlus() {
//        return plus;
//    }
//
//    public int getMin() {
//        return min;
//    }
//
//    public EditText getInp() {
//        return inp;
//    }


}
