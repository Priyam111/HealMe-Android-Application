package com.example.myapplication;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.gms.ads.interstitial.InterstitialAd;

public class MainActivity extends AppCompatActivity {
    private ImageButton calc,progress,goals,profile,about,cal;
    private ImageView ui;
    private Button bt;
    private AdView mAdView;
    private InterstitialAd inad;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        AdView adView = new AdView(this);
        adView.setAdSize(AdSize.BANNER);
        adView.setAdUnitId("ca-app-pub-3940256099942544/6300978111");

        DBhelpee one=new DBhelpee(this);
        SQLiteDatabase db=one.getReadableDatabase();

// TODO: Add adView to your view hierarchy.
        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });


        mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);
        calc=(ImageButton) findViewById(R.id.calculator_);
        goals=(ImageButton) findViewById(R.id.goal_);
        about=(ImageButton) findViewById(R.id.about_);
        progress=findViewById(R.id.progress_);
        profile=findViewById(R.id.profile_);
        ui=findViewById(R.id.bgmenu);
        cal=findViewById(R.id.cal);



        mAdView.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                // Code to be executed when an ad finishes loading.
                super.onAdLoaded();
                Toast.makeText(MainActivity.this, "AD LOADED", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onAdFailedToLoad(LoadAdError adError) {
                // Code to be executed when an ad request fails.
                super.onAdFailedToLoad(adError);
                mAdView.loadAd(adRequest);
            }

            @Override
            public void onAdOpened() {
                // Code to be executed when an ad opens an overlay that
                // covers the screen.
                super.onAdOpened();
            }

            @Override
            public void onAdClicked() {
                // Code to be executed when the user clicks on an ad.
                super.onAdClicked();

            }

            @Override
            public void onAdClosed() {
                // Code to be executed when the user is about to return
                // to the app after tapping on an ad.
            }
        });

        cal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this, " CALORIE TRACKER OPENED ", Toast.LENGTH_SHORT).show();
                Intent intent=new Intent(MainActivity.this,about.class);
                startActivity(intent);
            }
        });


        goals.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this, " MY GOALS OPENED ", Toast.LENGTH_SHORT).show();
                Intent intent=new Intent(MainActivity.this,Goal.class);
                startActivity(intent);
            }
        });

        about.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this, " ABOUT US ", Toast.LENGTH_SHORT).show();
                Intent intent=new Intent(MainActivity.this,about.class);
                startActivity(intent);

            }
        });

        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this, " PROFILE ", Toast.LENGTH_SHORT).show();
                Intent intent=new Intent(MainActivity.this,profile.class);
                startActivity(intent);

            }
        });

        progress.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this, " PROGRESS ", Toast.LENGTH_SHORT).show();
                Intent intent=new Intent(MainActivity.this,graph_selection.class);
                startActivity(intent);

            }
        });
//
        calc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this, " HELLOW", Toast.LENGTH_SHORT).show();
                Intent intent=new Intent(MainActivity.this,Secondscreen.class);
                startActivity(intent);
            }
        });



    }


}

