package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import java.io.ByteArrayOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class profile extends AppCompatActivity {
    private ImageView bg,dp;
    private ToggleButton sexbut,switchbp;
    private Button next;
    private EditText inpname,indob,inweight,inheight;
    private CheckBox tglbp,tgldibat,tglheart,tglthyroid;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        DBhelpee one=new DBhelpee(this);
        SQLiteDatabase db=one.getReadableDatabase();


        bg=findViewById(R.id.bgprofile);
        dp=findViewById(R.id.dp);
        sexbut=findViewById(R.id.sexbut);
        next=findViewById(R.id.next);

        inpname=findViewById(R.id.inpname);
        indob=findViewById(R.id.inpdob);
        inheight=findViewById(R.id.inpheightdata);
        inweight=findViewById(R.id.inpweightdata);

        tglbp=findViewById(R.id.tglbp);
        tgldibat=findViewById(R.id.tgldibat);
        tglheart=findViewById(R.id.tglheart);
        tglthyroid=findViewById(R.id.tglthyroid);

        switchbp=findViewById(R.id.switchbp);
        sexbut=findViewById(R.id.sexbut);

        switchbp.setEnabled(false);

        dp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                choosepic();

            }
        });

        tglbp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(tglbp.isChecked()){
                    switchbp.setEnabled(true);
                }
                else {
                    switchbp.setEnabled(false);
                }
            }
        });


        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String namedata=inpname.getText().toString();
                String dobdata=indob.getText().toString();
                String weightdata=inweight.getText().toString();
                String heightdata=inheight.getText().toString();

                EditText[] inputs={inpname,indob,inweight,inheight};

                String[] allinputs={namedata,dobdata,weightdata,heightdata};

                SimpleDateFormat simpleTimeFormat = new SimpleDateFormat("dd MMM yyyy", Locale.getDefault());
                long dated=new Date().getTime();
                String Enttime=simpleTimeFormat.format(dated);

                boolean b=( (namedata).isEmpty() || dobdata.isEmpty() || weightdata.isEmpty() || heightdata.isEmpty() );

                if(b)  {
                    Toast.makeText(profile.this, "ALL FIELDS ARE MANDATORY", Toast.LENGTH_SHORT).show();
                    for (int i=0;i<=3;i++) {
                        if (allinputs[i].isEmpty()) {
                            inputs[i].setError("THIS FIELD IS MISSING");
                        }
                    }
                }
                else{

                    Boolean dibatdata,thyroiddata,heartdata;
                    int sexdata,bpdata = 0;

                    if(tglbp.isChecked()){
                        if(switchbp.isSelected()){
                            bpdata=1;
                        }
                        else{
                            bpdata=2;
                        }
                    }
                    else{
                        bpdata=0;
                    }

                    if(tglthyroid.isChecked()){
                        thyroiddata=true;
                    }
                    else {
                        thyroiddata=false;
                    }


                    if(tgldibat.isChecked()){
                        dibatdata=true;
                    }
                    else {
                        dibatdata=false;
                    }


                    if(tglheart.isChecked()){
                        heartdata=true;
                    }
                    else {
                        heartdata=false;
                    }


                    if(sexbut.isSelected()){
                        sexdata=1;
                    }
                    else{
                        sexdata=2;
                    }

                    byte[] bytesPPic=imagetobyte(dp);


                    Boolean res=one.insert(weightdata,heightdata,namedata,dobdata,thyroiddata,dibatdata,heartdata,bpdata,Enttime,1,bytesPPic,sexdata);


                    if(res=true){
                        Toast.makeText(profile.this, "DATA SAVED", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        Toast.makeText(profile.this, "DATA FAILED", Toast.LENGTH_SHORT).show();
                    }
                    Toast.makeText(profile.this, "SUCCESS", Toast.LENGTH_SHORT).show();
                }



//                Toast.makeText(profile.this, "DATA ENTERED", Toast.LENGTH_SHORT).show();

            }
        });
    }

    private void choosepic(){
        final AlertDialog.Builder builder=new AlertDialog.Builder(profile.this);
        LayoutInflater inflater=getLayoutInflater();
        View dialogView=inflater.inflate(R.layout.alertdialog,null);
        builder.setCancelable(false);
        builder.setView(dialogView);

        ImageView gallery=dialogView.findViewById(R.id.gallery);
        ImageView camera=dialogView.findViewById(R.id.camera);

        AlertDialog alertDialogimage = builder.create();
        alertDialogimage.show();

        gallery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                takegallery();
                alertDialogimage.cancel();

            }
        });



        camera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(checkAndRequestPer()){
                    takecamera();
                    alertDialogimage.cancel();
                }

            }
        });
    }



    private void takegallery(){
        Intent pickphoto=new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(pickphoto,1);

    }



    private void takecamera(){
        Intent pickpicture=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if(pickpicture.resolveActivity(getPackageManager())!=null){
            startActivityForResult(pickpicture,2);
        }
    }



    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        switch ((requestCode)){
            case 1:
                if(resultCode==RESULT_OK){
                    Uri selectedImageUri=data.getData();
                    dp.setImageURI(selectedImageUri);
                }
                break;
            case 2:
                if(resultCode==RESULT_OK){
                    Bundle bundle=data.getExtras();
                    Bitmap bitmapImage=(Bitmap) bundle.get("data");
                    dp.setImageBitmap(bitmapImage);
                }
        }
    }



    private boolean checkAndRequestPer() {
        if (Build.VERSION.SDK_INT >= 23) {
            int cameraPermission = ActivityCompat.checkSelfPermission(profile.this, Manifest.permission.CAMERA);
            if (cameraPermission == PackageManager.PERMISSION_DENIED) {
                ActivityCompat.requestPermissions(profile.this, new String[]{Manifest.permission.CAMERA},20);
                return false;
            }
        }
        return true;
    }



    private void onRequestPermissionResult(int resultcode, @NonNull String[] permissions,@NonNull int[] grantResults){
        super.onRequestPermissionsResult(resultcode,permissions,grantResults);
        if(resultcode==20 && grantResults[0]==PackageManager.PERMISSION_GRANTED){
            takecamera();
        }
        else {
            Toast.makeText(this, "OKAY", Toast.LENGTH_SHORT).show();
        }
    }



    private byte[] imagetobyte(ImageView imageView){
        Bitmap bitmap;
        bitmap = ((BitmapDrawable) imageView.getDrawable()).getBitmap();
        ByteArrayOutputStream byteArrayOutputStream=new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG,100,byteArrayOutputStream);
        return byteArrayOutputStream.toByteArray();
    }

}