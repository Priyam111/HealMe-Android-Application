package com.example.myapplication;

import static android.content.ContentValues.TAG;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;


import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.material.textfield.TextInputEditText;

import java.text.DecimalFormat;

public class Secondscreen extends AppCompatActivity {
    String result="com.example.myapplication.MY_APK.result";
    private InterstitialAd mInterstitialAd;
    private Button button;
    private TextView textview2,review;
    private ToggleButton toggleButton;
    private EditText editText;
    private TextView textView;
    private ToggleButton toggleButton2;
    private TextView txtinch;
    private EditText inpweight;
    private EditText inpheight;
    private EditText inpft;
    private TextView txtft;
    private Object view;
    private ImageView imageView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_secondscreen);

        button=findViewById(R.id.submit);
        textview2=findViewById(R.id.textView2);
        editText=findViewById(R.id.age);
        toggleButton=findViewById(R.id.radiounit);
        textView=findViewById(R.id.kg);
        toggleButton2=findViewById(R.id.toggleButton2);
        txtinch=findViewById(R.id.inch);
        inpweight=findViewById(R.id.inpweight);
        inpheight=findViewById(R.id.inpheight);
        txtft=findViewById(R.id.txtft);
        inpft=findViewById(R.id.inpft);
        review=findViewById(R.id.review);

//        imageView=findViewById(R.id.imageView);


        toggleButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (toggleButton.isChecked()) {
                    textView.setText("POUNDS");
                }
                else {
                    textView.setText("K.G");
                }
            }
        });

        toggleButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (toggleButton2.isChecked()) {
                    inpft.setEnabled(false);
                    inpft.setHint("    ");
                    txtft.setEnabled(false);
                    inpheight.setHint("ENTER C.M");
                    txtinch.setText("C.M");
                }
                else {
                    inpft.setEnabled(true);
                    inpft.setHint("ENTER FT");
                    txtft.setEnabled(true);
                    inpheight.setHint("ENTER INCH");
                    txtinch.setText("INCH");
                }
            }
        });




        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String wgt=inpweight.getText().toString();
                String hgt=inpheight.getText().toString();
                String valft=inpft.getText().toString();
                String age=editText.getText().toString();
                EditText[] inputs={editText,inpweight,inpft,inpheight};

                String[] allinputs={age,wgt,valft,hgt};
                boolean a=( (age).isEmpty() || wgt.isEmpty() || hgt.isEmpty() );
                boolean b=( valft.isEmpty() && (! toggleButton2.isChecked())) ;

                if(  a ||  b )  {
                    Toast.makeText(Secondscreen.this, "ALL FIELDS ARE MANDATORY", Toast.LENGTH_SHORT).show();
                    for (int i=0;i<=3;i++) {
                        if (allinputs[i].isEmpty()) {
                            inputs[i].setError("THIS FIELD IS MISSING");
                        }
                    }
                    textview2.setText("__________________________");
                }


                else {
                    double wgt_=Double.parseDouble(wgt);
                    double hgt_=Double.parseDouble(hgt);
                    if (! toggleButton2.isChecked()){
                        double valft_=Double.parseDouble(valft);
                        double ft_inch=(valft_ * 12)+hgt_;
                    }

                    if (toggleButton.isChecked()) {
                        wgt_= (wgt_ / 2.205);
                    }
                    else {
                        wgt_=wgt_*1;
                    }

                    if (toggleButton2.isChecked()){
                        hgt_= (hgt_ *(0.01));
                    }
                    else {
                        double valft_=Double.parseDouble(valft);
                        double ft_inch=(valft_ * 12)+hgt_;
                        hgt_=(ft_inch *(2.54)*(0.01));
                    }
                    double BMI=wgt_/(hgt_ * hgt_);
                    Toast.makeText(Secondscreen.this, "SUCSSFULL ! ", Toast.LENGTH_SHORT).show();
                    textview2.setText("BMI - "+String.valueOf(new DecimalFormat("##.#").format(BMI)));
                    if(BMI<18.5){
                        review.setText(">>  THIN  <<");
                        review.setTextColor(Color.parseColor("#008000"));
                    }
                    if ((BMI>23) && (BMI <25.1)){
                        review.setText(">>  PERFECT  >>");
                        review.setTextColor(Color.parseColor("#008000"));
                    }
                    if ((BMI>25.1 ) && ( BMI <30)){
                        review.setText(">>  OVERWEIGHT  >>");
                        review.setTextColor(Color.parseColor("#008000"));
                    }
                    if ((BMI>30 ) && ( BMI <34.9)){
                        review.setText(">>  OBESE  >>");
                        review.setTextColor(Color.parseColor("#008000"));
                    }
                    if ((BMI>34.9 ) && ( BMI <40)){
                        review.setText(">>  MORIBLY OBESE  >>");
                        review.setTextColor(Color.parseColor("#008000"));
                    }

                }

            }
        });


    }

}