package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class weightgoal extends AppCompatActivity {
    private ImageView bg;
    private EditText inpwgt,inptwgt,inptime,inpage;
    private Button done;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weightgoal);

        dbwgt two=new dbwgt(this);
        SQLiteDatabase db=two.getReadableDatabase();

        bg=findViewById(R.id.bgheightgoal);

        inptime=findViewById(R.id.deadline);
        inptwgt=findViewById(R.id.target);
        inpwgt=findViewById(R.id.current);
        inpage=findViewById(R.id.inpage);

        done=findViewById(R.id.done);

       done.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {


               String dl=inptime.getText().toString();
               String cw=inpwgt.getText().toString();
               String tw=inptwgt.getText().toString();
               String ag=inpage.getText().toString();

               SimpleDateFormat simpleTimeFormat = new SimpleDateFormat("dd MMM yyyy", Locale.getDefault());
               long dated=new Date().getTime();
               String Enttime=simpleTimeFormat.format(dated);


               EditText[] inputs={inpwgt,inptwgt,inptime,inpage};
               String[] allinputs={dl,cw,tw,ag};


               boolean b=( (dl).isEmpty() || cw.isEmpty() || tw.isEmpty() || ag.isEmpty() );


               if(b)  {
                   Toast.makeText(weightgoal.this, "ALL FIELDS ARE MANDATORY", Toast.LENGTH_SHORT).show();
                   for (int i=0;i<=3;i++) {
                       if (allinputs[i].isEmpty()) {
                           inputs[i].setError("THIS FIELD IS MISSING");
                       }
                   }
               }
               else {
                   Boolean res=two.insert(cw,tw,dl,Enttime);

                   if(res=true){
                       Toast.makeText(weightgoal.this, "DATA SAVED", Toast.LENGTH_SHORT).show();
                   }
                   else {
                       Toast.makeText(weightgoal.this, "DATA FAILED", Toast.LENGTH_SHORT).show();
                   }

               }
           }
       });
    }
}