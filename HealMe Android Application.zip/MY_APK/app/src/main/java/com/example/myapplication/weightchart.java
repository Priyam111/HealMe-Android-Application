package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Locale;

public class weightchart extends AppCompatActivity {
    LineChart lineChart;
    SQLiteDatabase sqLiteDatabase;
    DBhelpee dBhelpee;
    LineDataSet lineDataSet=new LineDataSet(null,null);
    ArrayList <ILineDataSet> dataSets=new ArrayList<>();
    LineData lineData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_progress);

        dBhelpee=new DBhelpee(this);
        sqLiteDatabase=dBhelpee.getWritableDatabase();

        lineChart = findViewById(R.id.graph);
        showdata();
        lineDataSet.setLineWidth(14);

    }

    private void showdata() {
        lineDataSet.setValues(getdataval());
        lineDataSet.setLabel("DataSet1");
        dataSets.clear();
        dataSets.add(lineDataSet);
        lineData=new LineData(dataSets);
        lineChart.clear();
        lineChart.setData(lineData);
        lineChart.invalidate();



    }

    private ArrayList<Entry> getdataval()
    {
        ArrayList<Entry>getdata  = new ArrayList<>();
        String[] Columns={"xVal","yVal"};
        Cursor cursor=sqLiteDatabase.query("alluserdata",null,null,null,null,null,null);


        for (int i=0;i<cursor.getCount();i++){
            cursor.moveToNext();
            getdata.add(new Entry(cursor.getFloat(9),cursor.getFloat(1)));
        }
        return getdata;
    }

}