package com.example.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class dbwgt  extends SQLiteOpenHelper {
    public static final String dbname="tableweightgoal.db";
    public dbwgt(Context context) {
        super(context, dbname, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase DB) {

        String cr=("create table  tableweightgoal(Curwgt String,Tarwgt String,Deadwgt String,Enttime String)");
        DB.execSQL(cr);
    }

    @Override
    public void onUpgrade(SQLiteDatabase DB, int i, int i1) {
        DB.execSQL("drop table if exists tableweightgoal");
        onCreate(DB);
    }

    public Boolean insert(String  Curwgt,String Tarwgt,String Deadwgt,String Enttime) {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("Curwgt", Curwgt);
        contentValues.put("Tarwgt", Tarwgt);
        contentValues.put("Deadwgt", Deadwgt);
        contentValues.put("Enttime", Enttime);

        long result = DB.insert("tableweightgoal", null, contentValues);
        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }

    public Boolean update(String  Curwgt,String Tarwgt,String Deadwgt,String Enttime) {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("Curwgt", Curwgt);
        contentValues.put("Tarwgt", Tarwgt);
        contentValues.put("Deadwgt", Deadwgt);
        contentValues.put("Enttime", Enttime);
        Cursor cursor = DB.rawQuery("Select * from tableweightgoal where Tarwgt=?", new String[]{Tarwgt});
        if (cursor.getCount() > 0) {
            long result = DB.update("tableweightgoal", contentValues, "Tarwgt=?", new String[]{Tarwgt});
            if (result == -1) {
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }
    }

    public Boolean delete(String Tarwgt) {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        Cursor cursor = DB.rawQuery("Select * from tableweightgoal where Tarwgt=?", new String[]{Tarwgt});
        if (cursor.getCount() > 0) {
            long result = DB.update("tableweightgoal", contentValues, "Tarwgt=?", new String[]{Tarwgt});
            if (result == -1) {
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }
    }

    public Cursor getdata() {
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("Select * from tableweightgoal", null);
        return cursor;
    }

    public Cursor getprofdata() {
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("Select weight from tableweightgoal", null);
        return cursor;
    }

}
