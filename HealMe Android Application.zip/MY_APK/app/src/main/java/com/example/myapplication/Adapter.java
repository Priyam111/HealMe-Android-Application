package com.example.myapplication;

import android.view.LayoutInflater;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class Adapter extends RecyclerView.Adapter<Adapter.ViewHolder>{

    private List<model> foodlist;

    public Adapter (List<model>foodlist){this.foodlist=foodlist;}

    int quantity=0;



    @NonNull
    @Override
    public Adapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.itemdesign,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Adapter.ViewHolder holder, int position) {
        int fp_=foodlist.get(position).getFp();
//        EditText inp_=foodlist.get(position).getInp();
        String fn_=foodlist.get(position).getFn();
        String cd_=foodlist.get(position).getCd();
        String ci_=foodlist.get(position).getCi();

//        int plus_=foodlist.get(position).getPlus();
//        int min_=foodlist.get(position).getMin();

//        holder.setData(fp_,inp_,fn_,cd_,plus_,min_);
        holder.setData(fp_,fn_,cd_,ci_);

    }

    @Override
    public int getItemCount() {

        return foodlist.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        protected ImageView fp;
        protected TextView fn,cal,ci,cd;
        protected ImageView min,plus;




        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            fp=itemView.findViewById(R.id.i1);
            fn=itemView.findViewById(R.id.fn1);
            cal=itemView.findViewById(R.id.cd);
            ci=itemView.findViewById(R.id.calinf);
            int data=0;



            min=itemView.findViewById(R.id.minus);
            plus=itemView.findViewById(R.id.plus);



            plus.setTag(R.integer.plus_view,itemView);
            min.setTag(R.integer.min_view,itemView);


            plus.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    quantity=quantity+1;
                    cal.setText(String.valueOf(quantity));
//                    inp.setHint(String.valueOf(quantity));
                }
            });


            min.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(quantity==0){
                        quantity=0;
                        cal.setText(String.valueOf(quantity));

                    }
                    else{
                        quantity=quantity-1;
                        cal.setText(String.valueOf(quantity));

                    }

                }
            });

        }
//        public void setData(int fp_, EditText inp_, String fn_, String cd_, int plus_, int min_) {
        public void setData(int fp_,String fn_, String cd_,String ci_) {
            fp.setImageResource(fp_);
            fn.setText(fn_);
            cal.setText(cd_);
            ci.setText(ci_);


//            min.setImageResource(min_);
//            plus.setImageResource(plus_);

        }
//        public void onClick(View v){
//            if(v.getId()==min.getId()){
//                View tempview=(View)  min.getTag(R.integer.min_view);
//                TextView tv=(TextView) cal.findViewById(R.id.cd);
//                int number=Integer.parseInt(tv.getText().toString())-1;
//                tv.setText(String.valueOf(number));
//
//            }
//        }
    }
}
