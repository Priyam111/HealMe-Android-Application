package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;
import java.util.List;

public class about extends AppCompatActivity {


    private TextView title,total,result;
    private SearchView searchView;
    private TabLayout tab;
    private Button save;

    private EditText inp;

    RecyclerView recyclerView;
    LinearLayoutManager layoutManager;
    List<model>foodlist;
    Adapter adapter;
    private ImageView a1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);



        title=findViewById(R.id.titlecal);
        total=findViewById(R.id.total);
        result=findViewById(R.id.result);

//        a1=findViewById(R.drawable.a);

        tab=findViewById(R.id.tab);
        searchView=findViewById(R.id.searchView);
        save=findViewById(R.id.save);


        initdata();
        initRecyclerView();

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(about.this, "DATA SAVED", Toast.LENGTH_SHORT).show();
            }
        });


    }

    private void initdata() {
        foodlist=new ArrayList<>();
        foodlist.add(new model(R.drawable.a1,"Boiled Egg","80/1Unit","__"));
        foodlist.add(new model(R.drawable.a2,"Egg Fried","110/1Unit","__"));
        foodlist.add(new model(R.drawable.a3,"Egg Omellete","120/1Unit","__"));
        foodlist.add(new model(R.drawable.a4,"Bread Butter","90/1Unit","__"));
        foodlist.add(new model(R.drawable.a5,"Chapati","60/1Unit","__"));
        foodlist.add(new model(R.drawable.a6,"Puri","75/1Unit","__"));
        foodlist.add(new model(R.drawable.a7,"Paratha","150/1Unit","__"));
        foodlist.add(new model(R.drawable.a8,"Idli","100/1Unit","__"));
        foodlist.add(new model(R.drawable.a9,"Dosa Plain","120/1Unit","__"));
        foodlist.add(new model(R.drawable.a10,"Dosa Masala","250/1Unit","__"));
        foodlist.add(new model(R.drawable.a11,"Sambhar","150/1Unit","__"));
        foodlist.add(new model(R.drawable.a12,"Cooked Rice","120/1Unit","__"));
        foodlist.add(new model(R.drawable.a13,"Fried Rice","150/1Unit","__"));
        foodlist.add(new model(R.drawable.a14,"Phulka","60/1Unit","__"));
        foodlist.add(new model(R.drawable.a15,"Naan","150/1Unit","__"));
        foodlist.add(new model(R.drawable.a16,"Dal","150/1Unit","__"));
        foodlist.add(new model(R.drawable.a17,"Curd","100/1Unit","__"));
        foodlist.add(new model(R.drawable.a18,"Curry","150/1Unit","__"));
        foodlist.add(new model(R.drawable.a19,"Salad","100/1Unit","__"));
        foodlist.add(new model(R.drawable.a20,"Papad","45/1Unit","__"));
        foodlist.add(new model(R.drawable.a23,"Cutlet","75/1Unit","__"));
        foodlist.add(new model(R.drawable.a24,"Black Tea","10/1Unit","__"));
        foodlist.add(new model(R.drawable.a25,"Tea","10/1Unit","__"));
    }

    private void initRecyclerView() {
        recyclerView =findViewById(R.id.recyc);
        layoutManager=new LinearLayoutManager(this);
        layoutManager.setOrientation(RecyclerView.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);
        adapter=new Adapter(foodlist);
        recyclerView.setAdapter(adapter);

    }
}