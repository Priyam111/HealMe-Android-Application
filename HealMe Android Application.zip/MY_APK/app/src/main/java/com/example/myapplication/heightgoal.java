package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class heightgoal extends AppCompatActivity {
    private ImageView bg;
    private EditText current,inpage,target,deadline;
    private Button done;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_heightgoal);

        DBhelpee one=new DBhelpee(this);
        SQLiteDatabase db=one.getReadableDatabase();


        bg=findViewById(R.id.bgheightgoal);

        deadline=findViewById(R.id.deadline);
        inpage=findViewById(R.id.inpage);
        current=findViewById(R.id.current);
        target=findViewById(R.id.target);

        done=findViewById(R.id.done);

        done.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String current_,inpage_,target_,deadline_;
                inpage_=inpage.getText().toString();
                current_=current.getText().toString();
                deadline_=deadline.getText().toString();
                target_=target.getText().toString();

                EditText[] inputs={current,inpage,target,deadline};

                String[] allinputs={current_,inpage_,target_,deadline_};

                boolean a=( (inpage_).isEmpty() || current_.isEmpty() || target_.isEmpty() ||deadline_.isEmpty() );

                if(a)  {
                    Toast.makeText(heightgoal.this, "ALL FIELDS ARE MANDATORY", Toast.LENGTH_SHORT).show();
                    for (int i=0;i<=3;i++) {
                        if (allinputs[i].isEmpty()) {
                            inputs[i].setError("THIS FIELD IS MISSING");
                        }
                    }
                }
                else{
//                    Boolean res=one.insert(weightdata,heightdata,namedata,dobdata,thyroiddata,dibatdata,heartdata,bpdata,Enttime,1,bytesPPic);
                    Toast.makeText(heightgoal.this, "SUCCESS", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}