package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.TextureView;
import android.widget.ImageView;
import android.widget.SearchView;
import android.widget.TextView;

import com.google.android.material.tabs.TabLayout;

public class calorie extends AppCompatActivity {
    private ImageView bg1,bg2,suy,ank;
    private TextView title,total,result,suytxt;
    private SearchView searchView;
    private TabLayout tab;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calorie);
//
//        suy= findViewById(R.id.suy1);
//        ank= findViewById(R.id.an1);
//
//        title=findViewById(R.id.titlecal);
//        total=findViewById(R.id.total);
//        result=findViewById(R.id.result);
//        suytxt=findViewById(R.id.txtsuy);
//
//        searchView=findViewById(R.id.searchView);

        tab=findViewById(R.id.tab);


    }
}